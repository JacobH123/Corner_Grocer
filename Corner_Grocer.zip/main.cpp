// Date: [6 / 17 / 23]
// Author : [Jacob Hellebrand]

#include <iostream>
#include <fstream>
#include <unordered_map>
#include <cctype>
#include <algorithm>
#include <string>
using namespace std;

// Function to display the menu options
void displayMenu() {
    cout << "Menu:\n";
    cout << "1. Find item frequency\n";
    cout << "2. Print item frequency list\n";
    cout << "3. Print item frequency histogram\n";
    cout << "4. Exit\n";
    cout << "Enter your choice: ";
}

// Function to create a backup data file
void createDataFile(const unordered_map<string, int>& itemFrequency) {
    ofstream outputFile("frequency.dat"); // Open the file for writing
    if (outputFile.is_open()) {
        // Write item frequencies to the file
        for (const auto& pair : itemFrequency) {
            outputFile << pair.first << " " << pair.second << "\n";
        }
        outputFile.close(); // Close the file
        cout << "Data file created: frequency.dat\n";
    }
    else {
        cout << "Error creating data file!\n";
    }
}

// Function to read the input file and compute item frequencies
unordered_map<string, int> readInputFile(const string& filename) {
    ifstream inputFile(filename); // Open the input file
    unordered_map<string, int> itemFrequency;
    if (inputFile.is_open()) {
        string item;
        while (inputFile >> item) {
            itemFrequency[item]++; // Increment the frequency of the item
        }
        inputFile.close(); // Close the file
    }
    else {
        cout << "Error opening input file: " << filename << "\n";
    }
    return itemFrequency;
}

// Function to find the frequency of a specific item
int findItemFrequency(const unordered_map<string, int>& itemFrequency, const string& item) {
    if (itemFrequency.count(item) > 0) {
        return itemFrequency.at(item); // Return the frequency of the item
    }
    return 0; // Item not found, so frequency is 0
}

// Function to print the item frequency list
void printItemFrequencyList(const unordered_map<string, int>& itemFrequency) {
    cout << "Item Frequency List:\n";
    for (const auto& pair : itemFrequency) {
        cout << pair.first << " " << pair.second << "\n"; // Print item and its frequency
    }
}

// Function to print the item frequency histogram
void printItemFrequencyHistogram(const unordered_map<string, int>& itemFrequency) {
    cout << "Item Frequency Histogram:\n";
    for (const auto& pair : itemFrequency) {
        cout << pair.first << " ";
        for (int i = 0; i < pair.second; i++) {
            cout << "*"; // Print asterisks based on the frequency
        }
        cout << "\n";
    }
}

int main() {
    // Read the input file and compute item frequencies
    unordered_map<string, int> itemFrequency = readInputFile("CS210_Project_Three_Input_File.txt");

    // Create a backup data file
    createDataFile(itemFrequency);

    int choice;
    string item;

    do {
        displayMenu();
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter the item to find its frequency: ";
            cin >> item;
            if (!item.empty()) {
                item[0] = toupper(item[0]);
                cout << "Frequency of " << item << ": " << findItemFrequency(itemFrequency, item) << "\n";
                break;
            }
        case 2:
            printItemFrequencyList(itemFrequency);
            break;
        case 3:
            printItemFrequencyHistogram(itemFrequency);
            break;
        case 4:
            cout << "Exiting the program...\n";
            break;
        default:
            cout << "Invalid choice! Please try again.\n";
            break;
        }

        cout << "\n";
    } while (choice != 4);

    return 0;
}
